package com.rest.process.restConsume;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestConsumeApplicationTests {

	@Test
	void contextLoads() {
	}

}
