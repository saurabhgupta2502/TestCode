package com.rest.process.restConsume.controller;

import java.util.List;
import java.util.stream.Collectors;

import javax.ws.rs.core.Response;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.rest.process.BO.ATMsBO;
import com.rest.process.restConsume.service.ExternalAPIConsumeService;


@RestController
public class ExternalAPIConsumeRestController {

	@Autowired
	private ExternalAPIConsumeService externalAPIConsumeService;
	
	@GetMapping("/getATMs")
	public Response getAllATM() throws JsonMappingException, JsonProcessingException {
		
		List<ATMsBO> jsonList = externalAPIConsumeService.getAtms();
//jsonList.stream().forEach(x -> System.out.println(x.getAddress().getCity()));

		return Response.status(200).entity(jsonList).build();
	}

	@GetMapping("/getATMs/{city}")
	public Response getATMsByCity(@PathVariable("city") String city) throws JsonMappingException, JsonProcessingException {
		List<ATMsBO> jsonList = externalAPIConsumeService.getAtms();
//		System.out.println(jsonList.stream().filter(x -> (x.getAddress().getCity().toLowerCase().equals(city.toLowerCase()))).collect(Collectors.toList()));

		return Response.status(200).entity(jsonList.stream().filter(x -> x.getAddress().getCity().toLowerCase().equals(city.toLowerCase())).collect(Collectors.toList())).build();
	}

}
