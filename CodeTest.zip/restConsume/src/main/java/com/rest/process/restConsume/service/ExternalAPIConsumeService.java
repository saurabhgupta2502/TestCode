package com.rest.process.restConsume.service;

import java.util.List;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.rest.process.BO.ATMsBO;

public interface ExternalAPIConsumeService {

	public List<ATMsBO> getAtms() throws JsonMappingException, JsonProcessingException;
}
